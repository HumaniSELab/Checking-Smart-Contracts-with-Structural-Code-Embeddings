# solidity-antlr4

[![Build Status](https://travis-ci.org/solidityj/solidity-antlr4.svg?branch=master)](https://travis-ci.org/solidityj/solidity-antlr4)

Solidity grammar for ANTLR4

## Author

Federico Bond ([@federicobond](https://github.com/federicobond))

## License

GPL 3.0
